import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.*;

/**
 * Web scraper designed to find the average timing a particular item is bought by a particular hero by top level Dota 2
 * players.
 * Simon Schumph
 */
public class D2PTStats {
    public static void main(String[] args){
        Scanner kb = new Scanner(System.in);

        //Reading the name of the hero to check stats of from the user
        System.out.print("Please enter hero name here: ");
        String heroName = kb.nextLine();

        //Reading the name of the item to check the timing of from the user
        System.out.print("Please enter item name here: ");
        String itemName = kb.nextLine();

        //Adding the hero name to the end of the D2PT URL to create the correct URL, requesting the HTML from the site,
        //then saving the rows of the table as a variable
        String d2ptURL = String.format("https://www.dota2protracker.com/hero/%s", heroName);
        Document d2ptPage = request(d2ptURL);
        Elements rows = d2ptPage.getElementsByAttributeValueContaining("items", itemName);

        //Each row of the table represents 1 game, find the minute the item was bought in each game and add it to the
        //list of timings
        ArrayList<Integer> timings = new ArrayList<Integer>();
        while (!rows.isEmpty()){
            Element row = rows.get(0);
            Elements item = row.getElementsByAttributeValue("title", itemName);
            int timing = Integer.parseInt(item.text().replace("m", ""));
            timings.add(timing);
            rows.remove(0);
        }

        //Sum all of the timings then divide by the count of timings to find the average time the item is purchased on
        //the given hero, then print to console
        double total = 0.0;
        for (int timing : timings){
            total += timing;
        }
        double avg = total/timings.size();
        System.out.printf("The average timing to purchase this item was %.2f minutes", avg);
    }

    /**
     * Requests the HTML of the given URL, prints the exception if an error occurs
     * @param url The URL of the site to request HTML from
     * @return The HTML of the requested site, or null if an exception occurred
     */
    private static Document request(String url){
        try {
            Connection con = Jsoup.connect(url);
            Document doc = con.get();
            return doc;
        }
        catch (IOException e){
            e.printStackTrace();
            return null;
        }
    }
}
